"""Run the installed vllm benchmark and validate its own detailed result."""
from pathlib import Path
import json,subprocess,sys
task=Path('/data1/megamoe_gain_20260905/bf16_e2e_20260907/bf16_repro_112_off_on_20260913')
arm=sys.argv[1];out=task/'results'/arm
assert (out/'acceptance_pass.json').is_file()
for length in (4096,6144):
    dest=out/('bench_'+str(length));dest.mkdir()
    command=['vllm','bench','serve','--backend','openai-chat','--model','/data2/weights/Qwen3.6-35B-A3B',
       '--base-url','http://127.0.0.1:8001','--endpoint','/v1/chat/completions','--num-prompts','160',
       '--trust-remote-code','--dataset-name','random','--ignore-eos','--seed','1024','--temperature','0',
       '--served-model-name','Qwen36','--random-input-len',str(length),'--random-output-len','256',
       '--random-range-ratio','0','--max-concurrency','32','--save-result','--save-detailed',
       '--result-dir',str(dest),'--result-filename','result.json']
    (dest/'command.json').write_text(json.dumps(command,indent=2))
    with (dest/'run.log').open('x') as log:
        rc=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=2400).returncode
    (dest/'run.rc').write_text(str(rc)+'\n');assert rc==0,('BENCH_RC',length,rc)
    result=json.loads((dest/'result.json').read_text())
    assert result['completed']==160, ('INCOMPLETE_REQUESTS',result.get('completed'))
    assert result['total_output_tokens']==160*256, ('UNEXPECTED_TOTAL_OUTPUT',result.get('total_output_tokens'))
    assert len(result['input_lens'])==len(result['output_lens'])==160
    assert all(x>0 for x in result['input_lens']) and all(x==256 for x in result['output_lens'])
    assert len(result['errors'])==160 and not any(result['errors']), 'BENCH_ERRORS'
    (dest/'validation_pass.json').write_text(json.dumps(dict(status='PASS',completed=160,input_requested=length,
       output_tokens_per_request=256,concurrency=32,seed=1024,temperature=0,profiling=False),indent=2))
    print('BENCH_COMPLETE',arm,length,result['completed'],result.get('output_throughput'),flush=True)
