# Qwen3.6 BF16 TP4 reproduction on 112.29.145.3

Four controlled arms: OFF A1, ON B1, ON B2, OFF A2. Eight original
vllm bench results, each 160 requests, 256 output tokens, concurrency 32,
requested input 4096 or 6144, seed 1024. Profiling is disabled.

All four fixed precision and repeat checks passed. This does not prove
losslessness on all inputs. Two samples per mode do not establish statistical
significance or guarantee the same percentage on future runs.

Recompute the complete aggregate from the existing validated pair collectors:

```bash
python3 summary/summarize_delivery_abba.py \
  bf16_repro_112_clientfixed_off_on_20260913/collected_results.log \
  bf16_repro_112_clientfixed_on_off_20260913/collected_results.log \
  --output recomputed_abba.json
```

Percentages below are (ON/OFF - 1) * 100. Positive latency means slower.

- 4096: throughput -0.0381%, TTFT +0.8712%, TPOT -0.1123%
- 6144: throughput -1.2766%, TTFT +2.3216%, TPOT +1.1145%

The unsuccessful_client_import_attempt directory preserves the earlier OFF
attempt. Its service and precision checks passed; the benchmark CLI failed
during imports before any timed results. Its cleanup succeeded. It is excluded
from performance samples. The repaired benchmark client explicitly imports the
same delivered plugin used by the server. Both modes have the same client
environment, server flags, and benchmark commands except the MegaMoe toggles.

environment/ records the exact migrated image, model content hashes, editable
source restoration, and CLI preflight. The archived deployment scripts are
individual historical migration steps, not a standalone cold-install command.
See the accompanying reproduction report for the retained-deployment commands.

source_export_manifest.json preserves the original remote file hashes;
manifest.json covers this complete deliverable, except itself.
