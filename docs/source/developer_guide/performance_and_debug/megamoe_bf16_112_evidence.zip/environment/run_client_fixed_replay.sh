#!/usr/bin/env bash
set -euo pipefail
root=/data02/megamoe_bf16_repro_20260913
base=/data1/megamoe_gain_20260905/bf16_e2e_20260907
test ! -e "$root/client_fixed_replay.log"
exec > "$root/client_fixed_replay.log" 2>&1
trap 'printf "%s\n" "$?" > "$root/client_fixed_replay.rc"' EXIT
test "$(cat "$root/client_preflight.rc")" = 0
python3 -I "$root/prepare_client_fixed_replay.py"
for order in off_on on_off; do
  task=$base/bf16_repro_112_clientfixed_${order}_20260913
  printf '%s\n' "$order" > "$root/client_fixed_replay_progress.txt"
  docker exec mm_bf16_serve_20260907 python3 "$task/preflight_devices.py"
  bash "$task/run_performance.sh"
  bash "$task/collect_results.sh" > "$task/collected_results.log"
done
docker exec mm_bf16_serve_20260907 python3 "$task/preflight_devices.py" > "$root/client_fixed_postflight.log" 2>&1
printf '0\n' > "$root/client_fixed_postflight.rc"
printf '%s\n' NEW_HOST_CLIENT_FIXED_ABBA_COMPLETE
