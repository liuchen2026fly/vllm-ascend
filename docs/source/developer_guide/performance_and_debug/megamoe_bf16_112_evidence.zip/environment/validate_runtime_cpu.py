"""Same seven CPU test files as the source baseline, plus concrete loader checks."""
from pathlib import Path
from unittest.mock import patch
import hashlib,json,os,subprocess,sys
import pytest,torch,torch_npu
t=Path('/data1/megamoe_gain_20260905/bf16_e2e_20260907/model_v31_runtime');r=t/'vllm-ascend-bf16'
libdirs=[Path(torch.__file__).parent/'lib',Path(torch_npu.__file__).parent/'lib']
loader_env=dict(os.environ,LD_LIBRARY_PATH=':'.join(str(p) for p in libdirs)+':'+os.environ.get('LD_LIBRARY_PATH',''))
manifest=json.loads((t/'runtime_binary_manifest.json').read_bytes());loader=[]
for row in manifest['files']:
 p=r/row['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
 out=subprocess.run(['ldd',str(p)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env=loader_env)
 assert out.returncode==0 and 'not found' not in out.stdout,(str(p),out.stdout)
 loader.append(dict(path=row['path'],ldd=out.stdout,torch_library_dirs=[str(p) for p in libdirs]))
(t/'loader_resolution.json').write_text(json.dumps(loader,indent=2)+'\n')
files=['a2/test_megamoe_local_partial.py','a2/test_megamoe.py','a2/test_megamoe_replicated_dispatch.py','test_megamoe_deferred_reduction.py','test_fused_moe.py','test_prepare_finalize.py','test_moe_mlp.py']
assert not torch.npu.is_initialized()
with patch.object(torch_npu.npu,'_lazy_init',side_effect=AssertionError('CPU_ONLY')),patch.object(torch.accelerator,'is_available',return_value=False):
 rc=pytest.main(['-q',*[str(r/'tests/ut/ops'/f) for f in files],'--confcutdir='+str(r/'tests/ut/ops')])
assert not torch.npu.is_initialized()
(t/'cpu_tests.rc').write_text(str(rc)+'\n')
print('NPU_INITIALIZED',torch.npu.is_initialized(),flush=True)
raise SystemExit(rc)
