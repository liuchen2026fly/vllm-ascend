#!/usr/bin/env bash
set -euo pipefail
root=/data02/megamoe_bf16_repro_20260913
exec > "$root/deployment.log" 2>&1
trap 'printf "%s\n" "$?" > "$root/deployment.rc"' EXIT
test "$(cat "$root/source_staging.rc")" = 0
test ! -e "$root/container_identity.json"
deadline=$((SECONDS+3600))
while test ! -e "$root/incoming/runtime_artifacts_manifest.json" || test ! -e "$root/incoming/image_inspect.json"; do
  test "$SECONDS" -lt "$deadline"
  sleep 10
done
printf '%s  %s\n' 334f69d7b2d80507785d77e7b273620b8901c3dae510a1d6f37e00cfb7f1914e "$root/incoming/runtime_image.tar.gz" | sha256sum -c -
python3 -I "$root/restore_artifacts.py"
gzip -dc "$root/incoming/runtime_image.tar.gz" | docker load
image=sha256:8dd949bff550c8e33211bbf6f0daa899c13eab3a1a140105bb2001509a6b568b
test "$(docker image inspect --format '{{.Id}}' "$image")" = "$image"
test -z "$(docker ps -aq --filter name='^/mm_bf16_serve_20260907$')"
docker run -d --name mm_bf16_serve_20260907 --network host --privileged \
  --shm-size 1g --security-opt label=disable \
  -v /usr/local/bin/npu-smi:/usr/local/bin/npu-smi \
  -v /usr/local/Ascend/driver:/usr/local/Ascend/driver \
  -v /etc/ascend_install.info:/etc/ascend_install.info \
  -v /usr/local/dcmi:/usr/local/dcmi \
  -v /data1:/data1 -v /data2:/data2 \
  -v /data01/models/Qwen3.6-35B-A3B:/data01/models/Qwen3.6-35B-A3B:ro \
  -v "$root:$root" \
  "$image" sleep infinity
docker inspect mm_bf16_serve_20260907 > "$root/container_identity.json"
docker exec mm_bf16_serve_20260907 bash "$root/validate_runtime_cpu.sh"
printf '%s\n' EXACT_RUNTIME_RESTORED_AND_CPU_VALIDATED
