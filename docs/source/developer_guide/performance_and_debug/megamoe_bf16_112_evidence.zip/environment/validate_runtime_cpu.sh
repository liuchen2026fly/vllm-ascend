#!/usr/bin/env bash
set -euo pipefail
root=/data02/megamoe_bf16_repro_20260913
runtime=/data1/megamoe_gain_20260905/bf16_e2e_20260907/model_v31_runtime
test ! -e "$runtime/cpu_tests.log"
set +u
source /usr/local/Ascend/ascend-toolkit/set_env.sh
set -u
export PYTHONPATH="$runtime/vllm-ascend-bf16:/data1/megamoe_gain_20260905/bf16_opt_20260907/torch_extension_v26:${PYTHONPATH:-}"
export TORCH_EXTENSIONS_DIR=/data1/megamoe_gain_20260905/bf16_opt_20260907/torch_extensions_v26
export ASCEND_RT_VISIBLE_DEVICES=''
python3 "$root/validate_runtime_cpu.py" > "$runtime/cpu_tests.log" 2>&1
