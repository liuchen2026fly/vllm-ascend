"""Restore manifest-verified generated artifacts without extracting through links."""
from pathlib import Path,PurePosixPath
import hashlib,json,os,tarfile
root=Path('/data02/megamoe_bf16_repro_20260913');incoming=root/'incoming'
base=Path('/data1/megamoe_gain_20260905')
manifest=json.loads((incoming/'runtime_artifacts_manifest.json').read_bytes())
assert manifest['status']=='PASS'
expected={row['path']:row for row in manifest['files']};assert len(expected)==len(manifest['files'])
stage=base/'artifacts.staging';assert not stage.exists();stage.mkdir()
with tarfile.open(incoming/'runtime_artifacts.tar.gz') as tar:
 members=tar.getmembers();assert {m.name for m in members}==set(expected)
 for member in members:
  name=PurePosixPath(member.name);assert not name.is_absolute() and '..' not in name.parts
  row=expected[member.name];p=stage/member.name
  if row['type']=='symlink':
   assert member.issym() and member.linkname==row['target'];continue
  assert member.isfile() or member.islnk()
  data=tar.extractfile(member).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],member.name
  p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);p.chmod(member.mode&0o777)
 for member in members:
  row=expected[member.name]
  if row['type']!='symlink':continue
  p=stage/member.name;target=row['target']
  if target.startswith('/'):
   assert target.startswith(('/data1/megamoe_gain_20260905/','/usr/local/Ascend/'))
  else:assert (p.parent/target).resolve().is_relative_to(stage)
  assert not any(x.is_symlink() for x in p.parents if x!=stage.parent)
  p.parent.mkdir(parents=True,exist_ok=True);p.symlink_to(target)
for rel in ['runtime_abi','bf16_opt_20260907/package_v30','bf16_opt_20260907/torch_extensions_v26']:
 dest=base/rel;assert not dest.exists();dest.parent.mkdir(parents=True,exist_ok=True);(stage/rel).rename(dest)
runtime=base/'bf16_e2e_20260907/model_v31_runtime/vllm-ascend-bf16'
for row in manifest['framework_symlinks']:
 path=runtime/row['path'];assert not path.exists() and not path.is_symlink(),str(path)
 assert row['target'].startswith(str(base/'runtime_abi')+'/')
 path.parent.mkdir(parents=True,exist_ok=True);path.symlink_to(row['target'])
for row in manifest['files']:
 p=base/row['path']
 if row['type']=='symlink':assert os.readlink(p)==row['target']
 else:assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],str(p)
for row in manifest['framework_symlinks']:assert (runtime/row['path']).exists(),row
(root/'artifacts_restored.rc').write_text('0\n')
print('GENERATED_ABI_AND_VENDOR_FILES_VERIFIED',len(expected),flush=True)
