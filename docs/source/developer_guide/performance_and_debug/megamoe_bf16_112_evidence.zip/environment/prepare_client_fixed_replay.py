"""Make a fresh replay with explicit client imports and fail-before-serve CLI gates."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

root = Path('/data02/megamoe_bf16_repro_20260913')
base = Path('/data1/megamoe_gain_20260905/bf16_e2e_20260907')
assert (root/'client_preflight.rc').read_text().strip() == '0'
assert (root/'replay_controller.rc').read_text().strip() == '1'
failed = base/'bf16_repro_112_off_on_20260913/results/off_user_A1'
assert (failed/'stop.rc').read_text().strip() == '0'
assert not list(failed.glob('bench_*/result.json'))
bundle = root/'client_fixed_inputs'
assert not bundle.exists()
shutil.copytree(root/'host_inputs', bundle)
inputs = json.loads((bundle/'inputs_manifest.json').read_bytes())
for name, sha in inputs['files'].items():
    assert hashlib.sha256((bundle/name).read_bytes()).hexdigest() == sha, name
m = json.loads((bundle/'model/manifest.json').read_bytes())
p = bundle/'model/run_performance.sh'
original = p.read_text()
va = str(base/'model_v31_runtime/vllm-ascend-bf16')
ext = '/data1/megamoe_gain_20260905/bf16_opt_20260907/torch_extension_v26'
client = 'docker exec -e PYTHONPATH="'+va+':'+ext+'" -e ASCEND_RT_VISIBLE_DEVICES= mm_bf16_serve_20260907'
needle = 'docker exec mm_bf16_serve_20260907 python3 "$task/benchmark.py"'
assert original.count(needle) == 1
fixed = original.replace(needle, client+' python3 "$task/benchmark.py"')
gate = '''# Check both CLI entrypoints before allocating devices or loading weights.
'''+client+''' vllm bench serve --help > "$task/client_bench_help.log" 2>&1
'''+client+''' vllm serve --help > "$task/client_serve_help.log" 2>&1
printf '0\\n' > "$task/client_preflight.rc"
'''
assert fixed.count('for arm in off_user_A1 on_B1; do') == 1
fixed = fixed.replace('for arm in off_user_A1 on_B1; do', gate+'for arm in off_user_A1 on_B1; do')
p.write_bytes(fixed.encode())
m['files']['run_performance.sh'] = hashlib.sha256(p.read_bytes()).hexdigest()
delta = dict(reason='Benchmark CLI default editable Ascend root was absent on target; service already used delivered source through PYTHONPATH',
             client_environment={'PYTHONPATH':va+':'+ext,'ASCEND_RT_VISIBLE_DEVICES':''},
             applies_to='All OFF and ON benchmark clients and preflight help commands',
             server_source_changed=False, server_environment_changed=False,
             benchmark_command_changed=False, benchmark_implementation_changed=False,
             guard='Both vllm bench serve --help and vllm serve --help must pass before any service launch',
             preserved_failed_attempt=str(failed.parent.parent))
m['client_import_repair'] = delta
(bundle/'model/manifest.json').write_bytes((json.dumps(m,indent=2)+'\n').encode())
inputs['files'] = {name:hashlib.sha256((bundle/name).read_bytes()).hexdigest() for name in inputs['files']}
(bundle/'inputs_manifest.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode())
(root/'client_import_repair.json').write_bytes((json.dumps(delta,indent=2)+'\n').encode())
for order in ['off-on','on-off']:
    work = base/('bf16_repro_112_clientfixed_'+order.replace('-','_')+'_20260913')
    subprocess.run(['python3','-I',str(bundle/'prepare_current_machine.py'),'--work',str(work),'--order',order],check=True)
print('FRESH_ABBA_PREPARED_WITH_IDENTICAL_SERVER_AND_BENCH_COMMANDS',flush=True)
