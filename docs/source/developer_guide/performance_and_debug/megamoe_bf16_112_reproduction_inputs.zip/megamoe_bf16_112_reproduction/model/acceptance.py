"""Reuse the accepted service identity, correctness and repeatability gates."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import urllib.request

root = Path('/data1/megamoe_gain_20260905/bf16_e2e_20260907/user_tp4_v31_overlap')
arm = sys.argv[1]
import re
assert re.fullmatch(r'(off_user|off_nooverlap|on)_[A-Z][0-9]+',arm)
out = root / 'results' / arm
pid = int((out / 'server.pid').read_text())


def stat(text):
    a = text[text.rfind(')') + 2:].split()
    return dict(state=a[0], ppid=int(a[1]), pgid=int(a[2]), sid=int(a[3]), start=int(a[19]))


initial = stat((out / 'server.initial_stat').read_text())
current = stat(Path('/proc/%d/stat' % pid).read_text())
assert current['start'] == initial['start'] and current['pgid'] == current['sid'] == pid
cmd = Path('/proc/%d/cmdline' % pid).read_bytes().split(b'\0')
assert b'/data2/weights/Qwen3.6-35B-A3B' in cmd and b'8001' in cmd
env = dict(x.split(b'=', 1) for x in Path('/proc/%d/environ' % pid).read_bytes().split(b'\0') if b'=' in x)
expected = b'1' if arm.startswith('on_') else b'0'
assert env[b'MEGAMOE'] == expected and env[b'HCCL_DETERMINISTIC'] == b'true'
assert env[b'MEGAMOE_SKIP_COMPILED'] == b'0'
assert env[b'ASCEND_CUSTOM_OPP_PATH'].startswith(str(Path('/data1/megamoe_gain_20260905/bf16_opt_20260907/package_v30/packages/vendors/mmbf16v30_transformer')).encode() + b':')
identities = {}
for p in Path('/proc').iterdir():
    if not p.name.isdigit():
        continue
    try:
        st = stat((p / 'stat').read_text())
        if st['pgid'] == pid and st['sid'] == pid:
            st['cmd'] = (p / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
            identities[p.name] = st
    except (FileNotFoundError, ProcessLookupError):
        continue
assert len(identities) >= 3
(out / 'startup_process_manifest.json').write_text(json.dumps(identities, indent=2))
(out / 'ready_identity.json').write_text(json.dumps(dict(pid=pid, arm=arm, start=current['start'],
    command=[x.decode() for x in cmd if x], environment={k.decode(): v.decode() for k,v in env.items()
    if k in (b'MEGAMOE',b'HCCL_DETERMINISTIC',b'MEGAMOE_SKIP_COMPILED',b'ASCEND_CUSTOM_OPP_PATH',b'PYTHONPATH')}), indent=2))
probe = root / 'probe_stability_only.py'
assert hashlib.sha256(probe.read_bytes()).hexdigest() == 'c2c0cefd2a042dda2129051cda755a6dadfacafd38cdabd2defad752331430a0'
assert not (out / 'probe.log').exists()
with (out / 'probe.log').open('x') as f:
    run = subprocess.run([sys.executable, str(probe), '8001', str(out / 'probe')], stdout=f, stderr=subprocess.STDOUT, timeout=240)
(out / 'probe.rc').write_text(str(run.returncode) + '\n')
assert run.returncode == 0

if arm.startswith('on_'):
    # Verify the fresh workers loaded the candidate vendor after actual requests.
    vendor_libraries = {}
    for worker_pid, worker in identities.items():
        if not worker['cmd'].startswith('VLLM::Worker_'):
            continue
        mapped = sorted({line.split()[-1] for line in (Path('/proc')/worker_pid/'maps').read_text().splitlines() if 'libcust_opapi.so' in line})
        assert '/data1/megamoe_gain_20260905/bf16_opt_20260907/package_v30/packages/vendors/mmbf16v30_transformer/op_api/lib/libcust_opapi.so' in mapped, (worker_pid, mapped)
        assert not any('/package_v26/packages/vendors/' in name for name in mapped), (worker_pid, mapped)
        vendor_libraries[worker_pid] = mapped
    assert len(vendor_libraries) == 4
    (out/'actual_vendor_libraries.json').write_text(json.dumps(vendor_libraries,indent=2))
repeats = json.loads((out / 'probe/stability_2k.json').read_text())
assert len(repeats) == 3 and all(x['choices'][0]['logprobs'] == repeats[0]['choices'][0]['logprobs'] for x in repeats)
payload = dict(model='Qwen36', messages=[
    dict(role='system',content='The repeated text below is neutral filler. Follow only the final user instruction.'),
    dict(role='user',content='Neutral filler. '*700+'\nFinal instruction: Reply with exactly the number 42. No explanation.')],
    max_tokens=16,temperature=0,stream=False,chat_template_kwargs={'enable_thinking':False})
request = urllib.request.Request('http://127.0.0.1:8001/v1/chat/completions',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
with urllib.request.urlopen(request,timeout=120) as response:
    result = json.load(response)
(out / 'long_semantic.json').write_text(json.dumps(dict(payload=payload,response=result),indent=2))
assert 512 <= result['usage']['prompt_tokens'] <= 4096
assert result['choices'][0]['message']['content'].strip() == '42'
log=(out/'server.log').read_text(errors='replace')
assert ('CANN MegaMoe sym-buffer alloc:' in log) == arm.startswith('on_'), 'MEGAMOE_SYM_BUFFER_INITIALIZATION_GATE'
assert b'--dtype' in cmd and b'bfloat16' in cmd and b'--quantization' not in cmd
assert env[b'ASCEND_RT_VISIBLE_DEVICES']==b'0,1,2,3'
def option(key):
    b=key.encode();assert cmd.count(b)==1,key
    return cmd[cmd.index(b)+1].decode()
assert option('--tensor-parallel-size')=='4' and option('--max-num-batched-tokens')=='8192'
assert option('--max-model-len')=='131072' and option('--mamba-ssm-cache-dtype')=='bfloat16'
assert b'--async-scheduling' in cmd and b'--no-enable-prefix-caching' in cmd
assert env[b'HCCL_BUFFSIZE']==b'1024' and env[b'OMP_NUM_THREADS']==b'100'
mode=arm.rsplit('_',1)[0]
expected_config=json.loads((root/'configs.json').read_text())[mode]
assert json.loads(option('--additional-config'))==expected_config
assert 'cannot be enabled at the same time' not in log, 'UNEXPECTED_CONFIG_DOWNGRADE'
if arm.startswith('on_'):assert 'BF16 local-partial MegaMoe retains shared-expert overlap.' in log, 'MISSING_EFFECTIVE_OVERLAP_CONFIRMATION'
with urllib.request.urlopen('http://127.0.0.1:8001/v1/models',timeout=10) as response:
    api_models=json.load(response)
(out/'api_models.json').write_text(json.dumps(api_models,indent=2))
assert any(x['id']=='Qwen36' for x in api_models['data'])
worker_names=[x['cmd'] for x in identities.values() if x['cmd'].startswith('VLLM::Worker_')]
assert len(worker_names)==4, ('EXPECTED_FOUR_WORKERS',worker_names)
(out/'requested_config_verified.json').write_text(json.dumps(dict(tp=4,ep=4,devices=[0,1,2,3],mode=mode,additional_config=expected_config,workers=worker_names),indent=2))

assert json.loads((out/'probe/cross_off_2k.json').read_text()) == dict(text_equal=True,logprobs_equal=True)
assert json.loads((out/'probe/cross_off_4k.json').read_text()) == dict(text_equal=True)
assert expected_config['mega_moe_local_partial'] == arm.startswith('on_')
(out / 'acceptance_pass.json').write_text(json.dumps(dict(status='PASS',arm=arm,three_2k_logprobs_identical=True,cross_off_2k_text_and_logprobs_exact=True,cross_off_4k_text_exact=True,scope='fixed requests only; no broad model lossless or performance claim'),indent=2))
print('ACCURACY_ARM_CORRECTNESS_STABILITY_PASS', arm, flush=True)


