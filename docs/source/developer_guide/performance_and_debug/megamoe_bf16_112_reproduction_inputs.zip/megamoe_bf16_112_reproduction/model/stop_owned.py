"""Stop only a recorded test server and its verified descendants."""
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import re

root = Path('/data1/megamoe_gain_20260905/bf16_e2e_20260907/user_tp4_v31_overlap')
tag = sys.argv[1]
assert re.fullmatch(r'(off_user|off_nooverlap|on)_[A-Z][0-9]+', tag)
out = root / 'results' / tag
pid = int((out / 'server.pid').read_text())


def parse_stat(text):
    fields = text[text.rfind(')') + 2:].split()
    return dict(state=fields[0], ppid=int(fields[1]), pgid=int(fields[2]),
                sid=int(fields[3]), start=int(fields[19]))


def snapshot():
    result = {}
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():
            continue
        try:
            stat = parse_stat((p / 'stat').read_text())
            stat['cmd'] = (p / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
            result[int(p.name)] = stat
        except (FileNotFoundError, ProcessLookupError):
            continue
    return result


initial = parse_stat((out / 'server.initial_stat').read_text())
all_procs = snapshot()
if pid not in all_procs:
    assert not [p for p, st in all_procs.items() if st['sid'] == pid and st['state'] != 'Z'], 'ORPHAN_WORKERS_REQUIRE_REVIEW'
    subprocess.run([sys.executable, str(root / 'preflight_devices.py')], check=True)
    (out / 'stop_status.txt').write_text('OWNED_SERVER_ALREADY_EXITED_PROCESSES_PORTS_DEVICES_CLEAR\n')
    raise SystemExit(0)
current = all_procs[pid]
assert current['start'] == initial['start'], 'PID_REUSE_GUARD'
assert current['sid'] == current['pgid'] == pid, 'SERVER_SESSION_GUARD'
assert 'vllm serve /data2/weights/Qwen3.6-35B-A3B' in current['cmd'] and '--port 8001 ' in current['cmd']
cmd=Path('/proc/%d/cmdline'%pid).read_bytes().split(b'\0')
env=dict(x.split(b'=',1) for x in Path('/proc/%d/environ'%pid).read_bytes().split(b'\0') if b'=' in x)
assert env[b'ASCEND_RT_VISIBLE_DEVICES']==b'0,1,2,3'
assert cmd.count(b'--tensor-parallel-size')==1 and cmd[cmd.index(b'--tensor-parallel-size')+1]==b'4'

owned = {pid}
while True:
    children = {p for p, st in all_procs.items() if st['ppid'] in owned}
    if children <= owned:
        break
    owned |= children
assert os.getpid() not in owned and len(owned) >= 3, ('DESCENDANT_GUARD', sorted(owned))
records = {p: all_procs[p] for p in owned}
manifest = out / 'stop_process_manifest.json'
assert not manifest.exists(), 'STOP_ALREADY_ATTEMPTED: inspect manifest and remaining state'
manifest.write_text(json.dumps(records, indent=2))


def remaining():
    now = snapshot()
    return [p for p, old in records.items() if p in now
            and now[p]['start'] == old['start'] and now[p]['state'] != 'Z']


def signal_verified(p, sig):
    now = snapshot().get(p)
    if now and now['start'] == records[p]['start'] and now['state'] != 'Z':
        try:
            os.kill(p, sig)
        except ProcessLookupError:
            pass  # The verified process exited between identity check and signal.


signal_verified(pid, signal.SIGTERM)
for limit, sig in ((60, signal.SIGTERM), (20, signal.SIGKILL), (10, None)):
    end = time.monotonic() + limit
    while remaining() and time.monotonic() < end:
        time.sleep(2)
    left = remaining()
    if not left:
        break
    if sig is not None:
        print('OWNED_REMAINING', left, 'SIGNAL', sig, flush=True)
        for p in left:
            signal_verified(p, sig)
assert not remaining(), ('OWNED_PROCESSES_REMAIN', remaining())
for _ in range(30):
    smi = subprocess.check_output(['npu-smi', 'info'], text=True)
    mem = [int(x) for x in re.findall(r'(\d+)\s*/\s*65536', smi)]
    clear = len(mem) == 8 and all(mem[i] < 6000 for i in (0,1,2,3))
    clear = clear and all(f'No running processes found in NPU {i}' in smi for i in (0,1,2,3))
    if clear:
        break
    time.sleep(2)
(out / 'devices_after_stop.txt').write_text(smi)
assert clear, ('DEVICES_NOT_CLEAR', mem)
with socket.socket() as sock:
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(('0.0.0.0', 8001))
assert not [p for p, st in snapshot().items() if st['pgid'] == pid and st['state'] != 'Z']
subprocess.run([sys.executable, str(root / 'preflight_devices.py')], check=True)
(out / 'stop_status.txt').write_text('OWNED_SERVER_STOPPED_PORT_PROCESSES_DEVICES_CLEAR\n')
print('OWNED_SERVER_STOPPED_PORT_PROCESSES_DEVICES_CLEAR', mem, flush=True)
