#!/usr/bin/env bash
set -euo pipefail
python3 - <<'PY'
from pathlib import Path
import datetime,hashlib,json
root=Path('/data1/megamoe_gain_20260905/bf16_e2e_20260907/user_tp4_v31_overlap')
assert (root/'controller.rc').read_text().strip()=='0'
assert (root/'evaluation.rc').read_text().strip()=='0'
assert (root/'progress.txt').read_text().strip()=='V31_FIRST_CONTROLLED_PAIR_COMPLETE'
manifest=json.loads((root/'manifest.json').read_text())
arms=['off_user_A1','on_B1']
records={};results={};configs={};precisions={};identities={};commands={};acceptance={}
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
for arm in arms:
 out=root/'results'/arm
 assert (out/'stop.rc').read_text().strip()=='0'
 acceptance[arm]=json.loads((out/'acceptance_pass.json').read_text())
 assert acceptance[arm]['status']=='PASS'
 configs[arm]=json.loads((out/'requested_config_verified.json').read_text())
 assert configs[arm]['additional_config']['multistream_overlap_shared_expert'] is True
 identities[arm]=json.loads((out/'ready_identity.json').read_text())
 precisions[arm]=json.loads((out/'probe/extended_precision.json').read_text())
 results[arm]={};records[arm]={};commands[arm]={}
 for length in [4096,6144]:
  dest=out/('bench_'+str(length))
  assert json.loads((dest/'validation_pass.json').read_text())['status']=='PASS'
  r=json.loads((dest/'result.json').read_text())
  assert r['completed']==160 and r['total_output_tokens']==40960
  assert len(r['errors'])==160 and not any(r['errors'])
  assert len(r['input_lens'])==len(r['output_lens'])==160 and set(r['output_lens'])=={256}
  results[arm][length]=r
  commands[arm][length]=json.loads((dest/'command.json').read_text())
  records[arm][length]=dict(result=str(dest/'result.json'),sha256=sha(dest/'result.json'),input_lens=r['input_lens'],output_lens=r['output_lens'])
off,on=arms
excluded={'enable_fused_mc2','mega_moe_local_partial'}
def norm_config(arm):return {k:v for k,v in configs[arm]['additional_config'].items() if k not in excluded}
assert norm_config(off)==norm_config(on),'ADDITIONAL_CONFIG_NOT_ALIGNED'
def norm_serve(arm):
 command=list(identities[arm]['command']);i=command.index('--additional-config')
 value=json.loads(command[i+1]);command[i+1]=json.dumps({k:v for k,v in value.items() if k not in excluded},sort_keys=True)
 return command
assert norm_serve(off)==norm_serve(on),'SERVE_COMMAND_NOT_ALIGNED'
for length in ['511','513','6144']:
 reference=precisions[off][length][0]['choices'][0]
 for arm in arms:
  entries=precisions[arm][length];assert len(entries)==3
  assert all(r['choices'][0]['text']==reference['text'] and r['choices'][0]['logprobs']==reference['logprobs'] for r in entries),'EXTENDED_PRECISION_MISMATCH'
libraries=json.loads((root/'results'/on/'actual_vendor_libraries.json').read_text())
assert len(libraries)==4
rows=[]
for length in [4096,6144]:
 a,b=results[off][length],results[on][length]
 assert a['input_lens']==b['input_lens'] and a['output_lens']==b['output_lens']
 ac,bc=commands[off][length][:],commands[on][length][:]
 for command in [ac,bc]:command[command.index('--result-dir')+1]='RESULT_DIRECTORY'
 assert ac==bc,'BENCH_COMMAND_NOT_ALIGNED'
 row=dict(input_requested=length)
 for metric in ['output_throughput','request_throughput','mean_ttft_ms','median_ttft_ms','mean_tpot_ms','median_tpot_ms','duration']:
  assert isinstance(a[metric],(int,float)) and isinstance(b[metric],(int,float)) and a[metric]>0,metric
  row[metric]=dict(off=a[metric],on=b[metric],change_percent=(b[metric]/a[metric]-1)*100)
 rows.append(row)
effective_settings=dict(manifest['performance_settings'],shared_overlap=True)
assert effective_settings==dict(input_lengths=[4096,6144],output_length=256,concurrency=32,requests_per_length=160,seed=1024,temperature=0,profiling=False,shared_overlap=True)
for arm in arms:
 for length in [4096,6144]:
  command=commands[arm][length]
  for option,expected in [('--random-input-len',length),('--random-output-len',256),('--max-concurrency',32),('--num-prompts',160),('--seed',1024),('--temperature',0)]:
   assert command.count(option)==1 and float(command[command.index(option)+1])==expected,(arm,option)
  assert '--profile' not in command
metadata_corrections={}
if manifest['performance_settings']!=effective_settings:
 assert root.name=='user_tp4_v31_overlap' and manifest['performance_settings']['shared_overlap'] is False, 'UNEXPECTED_EXPERIMENT_METADATA_MISMATCH'
 metadata_corrections={'performance_settings.shared_overlap':dict(recorded=False,verified=True,evidence='Both executed serve commands, configuration verification, no-downgrade log check, and ON effective-overlap log marker. Raw manifest preserved.')}
report=dict(status='V31_FIRST_CONTROLLED_PAIR_COLLECTED',utc=datetime.datetime.utcnow().isoformat()+'Z',
 effective_settings=effective_settings,manifest_metadata_corrections=metadata_corrections,manifest=manifest,manifest_sha256=sha(root/'manifest.json'),configs=configs,identities=identities,
 commands=commands,acceptance=acceptance,records=records,comparisons=rows,
 extended_precision_exact=True,actual_on_vendor_libraries=libraries,
 operator_gain_accepted=False,caution='One OFF/ON pair. Review magnitude and reverse order to confirm a candidate gain. Fixed precision requests do not prove all-input model losslessness.')
print('V31_CONTROLLED_PAIR_JSON',json.dumps(report,separators=(',',':')),flush=True)
PY
