# BF16 V31/V30 四卡复现输入

本包保留实际验收的模型测试脚本、固定精度参考、四卡算子用例和文件哈希。
适用于已保留部署的 18 机、mm_bf16_serve_20260907 容器及物理卡 0–3。
它不会安装运行时、替换生产源文件或自动停止其他服务。生产源码以精确 Git 提交为准：
vLLM Ascend 481b9570b7bf83b483f81d1a5450515e5f2a0e4a，
CANN 23617531fd023f5a90612e6bddb8d21f951af234。

输入清单 inputs_manifest.json 校验包内文件。准备器再次验证容器/镜像身份、
V31 运行时源文件、V30 内核与 V26 扩展二进制哈希，以及 BF16 模型文件状态。
其他机器需要单独恢复精确依赖与模型，不能直接沿用本机地址和二进制。

在 Linux 宿主机解压后，先用 prepare_current_machine.py 的 --work 参数指定
/data1/megamoe_gain_20260905/bf16_e2e_20260907 下一个全新的 bf16_repro_ 前缀目录；
--order off-on 或 on-off 决定对照顺序。准备器只创建新测试目录，不启动服务。

确认 0–3 卡、8001/29541 端口和 worker 空闲后，在宿主机运行新目录的
run_performance.sh。该脚本使用全局测试锁，依次执行服务启动、固定请求精度、
三次重复稳定性、4K/6K 各 160 请求 C32 压测，再按记录的 PID/启动时间/进程组清理。
两边 shared overlap=true，只改变 MegaMoe/local-partial 开关。

完成后运行新目录的 collect_results.sh，检查 controller/evaluation/stop 均为 0、
全部请求成功、两边实际输入/输出长度一致，以及精度检查通过。第二轮使用另一个新目录
和反序。计时期间不要启动 profiling 或大型离线分析。

operator/ 中是实际执行过的 14 用例四卡算子脚本。run_env.sh 配置 V30 vendor 和 V26
扩展，参考函数来自保留的 model_v15a_runtime 并由 REFERENCE_SHAS 锁定；
这是刻意保留的 OFF 算子基线，不是模型服务使用的 V31 运行时。
可在通过资源检查后，用该环境脚本调用 torchrun，四进程、主端口 29541，
执行 bench_tp4_local_partial_edges.py，并传入一个新的输出目录。
验收要求 56 个 case/rank 本地结果及最终归约结果逐位一致、四个 complete_rank 文件齐全。
不要原样重跑 operator/run_diagnostic.sh 中已经使用过的 run_A1 目录。

有限算子用例和固定请求不等价于所有输入的模型无损保证；本包不声称完成 BF16 全数据集评测。

模型复现清单的 performance_settings 已按实际命令校正为 shared_overlap=true；原始首轮清单保留在结果证据中，摘要勘误不更改实际启动参数或计时结果。准备器要求摘要、各组配置和精确源码提交一致。
