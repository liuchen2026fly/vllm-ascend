"""Stage a fresh replay against the preserved, hash-verified BF16 deployment."""
import argparse
import ast
import hashlib
import json
import subprocess
from pathlib import Path, PurePosixPath

parser = argparse.ArgumentParser()
parser.add_argument("--work", required=True)
parser.add_argument("--order", choices=["off-on", "on-off"], default="off-on")
args = parser.parse_args()
bundle = Path(__file__).resolve().parent
inputs = json.loads((bundle / "inputs_manifest.json").read_text())
for name, sha in inputs["files"].items():
    relative = PurePosixPath(name)
    assert not relative.is_absolute() and ".." not in relative.parts
    assert hashlib.sha256(bundle.joinpath(*relative.parts).read_bytes()).hexdigest() == sha, name
m = json.loads((bundle / "model/manifest.json").read_text())
original = "/data1/megamoe_gain_20260905/bf16_e2e_20260907/user_tp4_v31_overlap"
work = Path(args.work).resolve()
assert work.parent == Path(original).parent, "This replay targets the preserved current-machine deployment"
assert work.name.startswith("bf16_repro_") and not work.exists()
temporary = work.with_name(work.name + ".staging")
assert not temporary.exists() and temporary.parent == work.parent
identity = subprocess.check_output(
    ["docker", "inspect", "--format", "{{.Id}} {{.Image}} {{.State.Running}}", "mm_bf16_serve_20260907"],
    universal_newlines=True).strip()
assert identity == m["baseline_container"] + " " + m["baseline_image"] + " true"
runtime = Path(m["source_runtime"])
assert json.loads((bundle / "source_manifest.json").read_text())["commit"] == m["source_commit"]
assert json.loads((runtime / "source_manifest.json").read_text())["commit"] == m["source_commit"]
configs = json.loads((bundle / "model/configs.json").read_text())
for arm in m["rounds"]:
    assert configs[arm.rsplit("_", 1)[0]]["multistream_overlap_shared_expert"] == m["performance_settings"]["shared_overlap"]
assert m["performance_settings"]["shared_overlap"] is True
assert (runtime / "cpu_tests.rc").read_text().strip() == "0"
for row in json.loads((bundle / "source_manifest.json").read_text())["files"]:
    source = runtime / "vllm-ascend-bf16" / row["path"]
    assert hashlib.sha256(source.read_bytes()).hexdigest() == row["sha256"], str(source)
for name, sha in m["binaries"].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == sha, name
model = json.loads((bundle / "model_ready.json").read_text())
assert model["status"] == "PASS" and model["tensor_dtypes"] == {"BF16": 1045}
for row in model["files"]:
    actual = Path(row["path"]).stat()
    assert actual.st_size == row["size"] and actual.st_mtime_ns == row["mtime_ns"], row["path"]
files = {}
for name, sha in m["files"].items():
    raw = (bundle / "model" / name).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == sha
    files[name] = raw.decode("utf-8").replace(original, str(work))
probe = files["probe_stability_only.py"]
old_sha = hashlib.sha256(probe.encode()).hexdigest()
needle = "reference_path = out.parent.parent/'off_user_A1/probe/extended_precision.json'"
assert probe.count(needle) == 1
probe = probe.replace(needle, "reference_path = Path(__file__).resolve().parent/'golden/extended_precision.json'")
files["probe_stability_only.py"] = probe
assert files["acceptance.py"].count(old_sha) == 1
files["acceptance.py"] = files["acceptance.py"].replace(old_sha, hashlib.sha256(probe.encode()).hexdigest())
collector = (bundle / "collect_results.sh").read_text().replace(original, str(work))
if args.order == "on-off":
    files["run_performance.sh"] = files["run_performance.sh"].replace(
        "for arm in off_user_A1 on_B1;", "for arm in on_B2 off_user_A2;").replace(
        "V31_FIRST_CONTROLLED_PAIR_COMPLETE", "V31_REVERSE_CONTROLLED_PAIR_COMPLETE")
    collector = collector.replace("['off_user_A1','on_B1']", "['off_user_A2','on_B2']")
    collector = collector.replace("V31_FIRST_CONTROLLED_PAIR_COMPLETE", "V31_REVERSE_CONTROLLED_PAIR_COMPLETE")
    collector = collector.replace("V31_FIRST_CONTROLLED_PAIR_COLLECTED", "V31_REVERSE_CONTROLLED_PAIR_COLLECTED")
    m["rounds"] = ["on_B2", "off_user_A2"]
else:
    m["rounds"] = ["off_user_A1", "on_B1"]
files["collect_results.sh"] = collector
temporary.mkdir()
(temporary / "results").mkdir()
(temporary / "golden").mkdir()
for name, content in files.items():
    raw = content.encode("utf-8")
    assert b"\r" not in raw and b"\0" not in raw
    path = temporary / name
    assert path.parent == temporary
    if path.suffix == ".py":
        ast.parse(content, filename=name)
    path.write_bytes(raw)
    if path.suffix == ".sh":
        subprocess.run(["bash", "-n", str(path)], check=True)
for name in ["source_manifest.json", "runtime_binary_manifest.json", "model_ready.json"]:
    (temporary / name).write_bytes((bundle / name).read_bytes())
for name in ["stability_2k.json", "correctness.json", "extended_precision.json"]:
    (temporary / "golden" / name).write_bytes((bundle / "golden" / name).read_bytes())
m["files"] = {name: hashlib.sha256(value.encode()).hexdigest() for name, value in files.items()}
m["reproduced_from"] = original
m["performance_started"] = False
(temporary / "manifest.json").write_text(json.dumps(m, indent=2))
(temporary / "static.rc").write_bytes(b"0\n")
temporary.rename(work)
print("BF16_CURRENT_MACHINE_REPLAY_STAGED_NO_SERVICE_STARTED", work)
print("After checking the four devices, ports and workers, run: bash", work / "run_performance.sh")
