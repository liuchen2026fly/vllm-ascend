"""Four-rank diagnostic derived from the existing BF16 harness.

This is not model accuracy acceptance or an end-to-end benchmark. It separates
the production OFF routed chain, fallback weight representation, and early
top-k versus rank-partial accumulation before a new integration is designed.
"""

from datetime import timedelta
import hashlib
import json
import os
from pathlib import Path
import sys

import torch
import torch.distributed as dist
import torch_npu


HIDDEN, INTERMEDIATE, EXPERTS, TOPK, WORLD = 2048, 512, 256, 8, 4
MAX_SOURCE_TOKENS = 8192
FULL_CAPACITY = (MAX_SOURCE_TOKENS + 32) * TOPK
VA = Path('/data1/megamoe_gain_20260905/bf16_e2e_20260907/model_v15a_runtime/vllm-ascend-bf16')
REFERENCE_SHAS = {
    'vllm_ascend/ops/fused_moe/moe_mlp.py': '6236894da2ad643df88e826431cee0febbdf27f56159308be47cfca03e3baa34',
    'vllm_ascend/ops/fused_moe/token_dispatcher.py': '383a4c1d6d56ea2e9e7e85e51d7e2ac2070ab40fec65b122e19f95aa9fbe19b8',
    'vllm_ascend/ops/fused_moe/routed_experts.py': 'cbc834464d559072a341a55ac935e738395cf32aceb7bfa5f02933032afba03e',
    'vllm_ascend/device/device_op.py': 'c64dc4f693da5c537315fb66c9dd121b16be4ef9a7eaaae45390d1871760ba1d',
    'vllm_ascend/utils.py': '92a7a5e10e8da30299b09e3a44fa4c9fa5ba4b115cf92ad83ebc11195ac95970',
}


def fingerprint(tensors):
    digest = hashlib.sha256()
    for tensor in tensors:
        cpu = tensor.detach().cpu().contiguous()
        digest.update(str((tuple(cpu.shape), cpu.dtype)).encode())
        digest.update(cpu.view(torch.uint8).numpy().tobytes())
    return digest.hexdigest()


def difference(actual, expected):
    actual = actual.detach().cpu().contiguous()
    expected = expected.detach().cpu().contiguous()
    assert actual.shape == expected.shape and actual.dtype == expected.dtype == torch.bfloat16
    assert torch.isfinite(actual).all() and torch.isfinite(expected).all()
    err = actual.float() - expected.float()
    unequal = actual.view(torch.int16) != expected.view(torch.int16)
    indices = unequal.nonzero()[:8]
    return dict(
        bitwise_equal=bool(not unequal.any()),
        unequal_elements=int(unequal.sum()),
        elements=actual.numel(),
        max_abs=float(err.abs().max()),
        relative_l2=float(err.double().norm() / expected.double().norm().clamp_min(1e-20)),
        examples=[dict(index=i.tolist(), actual=float(actual[tuple(i)]), expected=float(expected[tuple(i)])) for i in indices],
    )


def validate_runtime():
    assert not torch.npu.is_initialized()
    vendor = Path(os.environ['MMGAIN_EXPECTED_VENDOR'])
    expected_path = os.environ['ASCEND_CUSTOM_OPP_PATH']
    assert expected_path.split(':')[0] == str(vendor)
    for name, expected in REFERENCE_SHAS.items():
        assert hashlib.sha256((VA / name).read_bytes()).hexdigest() == expected, name
    kernel = vendor / 'op_impl/ai_core/tbe/kernel/ascend910b/mega_moe/MegaMoe_d95b9716a3c9814f6ca27f3b4f54fc18.o'
    assert hashlib.sha256(kernel.read_bytes()).hexdigest() == os.environ['MMGAIN_EXPECTED_ND_SHA']
    # Follow the already accepted harness's import/bootstrap order.
    import vllm_ascend.utils as vu
    vu.bootstrap_custom_op_env()
    import vllm_ascend.vllm_ascend_C
    from cann_ops_transformer.ops.mega_moe import (
        _get_mega_moe_ccl_buffer_size,
        get_symm_buffer_for_mega_moe,
        mega_moe,
    )
    from vllm_ascend.ops.fused_moe.moe_comm_method import _append_cann_megamoe_dummy_tokens
    from vllm_ascend.ops.fused_moe.moe_mlp import unquant_apply_mlp
    assert os.environ['ASCEND_CUSTOM_OPP_PATH'] == expected_path
    assert not torch.npu.is_initialized()
    assert Path(vu.__file__).resolve() == (VA / 'vllm_ascend/utils.py').resolve()
    # The new output layout uses full replicated input, with explicit capacity
    # for every real and sentinel assignment. The isolated C++ query enforces it.
    buffer_mb = int(_get_mega_moe_ccl_buffer_size(
        WORLD, EXPERTS, MAX_SOURCE_TOKENS + 32, TOPK, HIDDEN,
        max_recv_token_num=FULL_CAPACITY, dispatch_quant_mode=0,
        dispatch_quant_out_dtype=None, comm_alg='local_partial_tp4',
    ))
    extension = json.loads(Path(os.environ['MMGAIN_EXPECTED_EXTENSION_MANIFEST']).read_text())
    assert extension['status'] == 'PASS' and extension['source_commit'] == 'a97d4ace25f5f8a51ca4584ebab941249022d5c7'
    assert buffer_mb == extension['buffer_mb'] and not torch.npu.is_initialized()
    from cann_ops_transformer.ops.mega_moe import _mega_moe_op_builder
    binary = Path(_mega_moe_op_builder.load().__file__)
    assert str(binary) == extension['binary']
    assert hashlib.sha256(binary.read_bytes()).hexdigest() == extension['sha256']
    print('CPU_REFERENCE_AND_BUFFER_GATE_PASS', buffer_mb, flush=True)
    return vendor, buffer_mb, get_symm_buffer_for_mega_moe, mega_moe, _append_cann_megamoe_dummy_tokens, unquant_apply_mlp


def main(output):
    vendor, buffer_mb, make_symm, mega_moe, append_dummy, apply_mlp = validate_runtime()
    rank, world = int(os.environ['RANK']), int(os.environ['WORLD_SIZE'])
    assert world == WORLD and os.environ['ASCEND_RT_VISIBLE_DEVICES'] == '0,1,2,3'
    outdir = Path(output)
    assert outdir.is_dir() and not (outdir / f'complete_rank{rank}.json').exists()
    torch.npu.set_device(rank)
    dev = torch.device(f'npu:{rank}')
    options = torch_npu._C._distributed_c10d.ProcessGroupHCCL.Options()
    options.hccl_config = {'hccl_buffer_size': buffer_mb}
    dist.init_process_group('hccl', timeout=timedelta(seconds=180), pg_options=options)
    dist.all_reduce(torch.ones(8, device=dev))
    local_e = EXPERTS // WORLD
    torch.manual_seed(1024 + rank)
    w1 = (torch.randn(local_e, HIDDEN, 2 * INTERMEDIATE, dtype=torch.bfloat16) * 0.01).to(dev)
    w2 = (torch.randn(local_e, INTERMEDIATE, HIDDEN, dtype=torch.bfloat16) * 0.01).to(dev)
    split1, split2 = [x.clone() for x in w1.unbind()], [x.clone() for x in w2.unbind()]
    views1, views2 = list(w1.unbind()), list(w2.unbind())
    assert torch_npu.get_npu_format(w1) == torch_npu.get_npu_format(w2) == 2
    assert all(torch_npu.get_npu_format(x) == 2 for x in split1 + split2 + views1 + views2)
    weight_sha = fingerprint([w1, w2])
    symm = make_symm(dist.group.WORLD, EXPERTS, MAX_SOURCE_TOKENS + 32, TOPK, HIDDEN, 2 * INTERMEDIATE,
                     max_recv_token_num=FULL_CAPACITY, dispatch_quant_mode=0, dispatch_quant_out_dtype=None,
                     comm_alg='local_partial_tp4')
    assert symm.ccl_buffer_size == 2 * buffer_mb * 1024 * 1024

    def gather(tensor):
        parts = [torch.empty_like(tensor) for _ in range(WORLD)]
        dist.all_gather(parts, tensor)
        return torch.cat(parts, dim=0)

    def reduced(tensor):
        tensor = tensor.clone()
        dist.all_reduce(tensor)
        return tensor

    cases = [(f'boundary{n}', n, False) for n in [1, 7, 8, 9, 31, 32, 511, 512, 513, 8191, 8192]] + [
        ('sparse_experts512', 512, False), ('skewed_experts8192', 8192, False), ('masked_tail513', 513, False)]
    with torch.inference_mode():
        for case_idx, (name, tokens, single_weight) in enumerate(cases):
            torch.manual_seed(8200 + case_idx)
            x = torch.randn(tokens, HIDDEN, dtype=torch.bfloat16).to(dev)
            ids = torch.rand(tokens, EXPERTS).topk(TOPK, dim=-1).indices.to(device=dev, dtype=torch.int32)
            if tokens == 1 or name == 'sparse_experts512':
                # Two active experts on every rank, all other real expert counts
                # zero. Sentinels still ensure valid device readiness.
                ids = torch.tensor([0, 1, 64, 65, 128, 129, 192, 193], dtype=torch.int32, device=dev).repeat(tokens, 1)
            elif name == 'skewed_experts8192':
                ids = torch.tensor([0, 1, 2, 3, 4, 64, 128, 192], dtype=torch.int32, device=dev).repeat(tokens, 1)
            input_active = torch.ones(tokens, dtype=torch.int8, device=dev)
            if name == 'masked_tail513':input_active[-17:] = 0
            probs = torch.rand(tokens, TOPK)
            probs /= probs.sum(dim=-1, keepdim=True)
            if single_weight:
                probs.zero_()
                probs[:, 0] = 1
            # Production forward casts router weights to hidden BF16 first.
            probs = probs.to(device=dev, dtype=torch.bfloat16)
            if name == 'masked_tail513':probs[-17:] = 0
            input_sha = fingerprint([x, ids, probs])
            input_hashes = [None] * WORLD
            dist.all_gather_object(input_hashes, input_sha)
            assert len(set(input_hashes)) == 1, 'REPLICATED_INPUT_MISMATCH'
            mask = (ids >= rank * local_e) & (ids < (rank + 1) * local_e)
            masked_probs = probs * mask
            routed, indices, counts, _ = torch_npu.npu_moe_init_routing_v2(
                x, ids, active_num=tokens * TOPK, expert_num=EXPERTS,
                expert_tokens_num_type=1, expert_tokens_num_flag=True,
                active_expert_range=[rank * local_e, (rank + 1) * local_e], quant_mode=-1,
            )
            groups = counts.to(torch.int64)
            assert groups.numel() == local_e
            expected_counts = torch.bincount(ids.flatten().to(torch.int64), minlength=EXPERTS)
            assert torch.equal(groups, expected_counts[rank * local_e:(rank + 1) * local_e])
            used_rows = int(groups.sum().item())
            assert 0 < used_rows <= routed.shape[0]
            abs_indices = torch.abs(indices)

            def valid_stages(stages):
                # Routing reserves B*K rows even when active_expert_range
                # selects fewer assignments. Compare only rows consumed by
                # the local expert groups; keep original API tensor shapes.
                return tuple(value[:used_rows] for value in stages[:3]) + stages[3:]

            def unpermute(expert_output, routing_probs):
                return torch_npu.npu_moe_token_unpermute(
                    permuted_tokens=expert_output, sorted_indices=abs_indices, probs=routing_probs
                )

            def staged(weights1, weights2):
                gate = torch_npu.npu_grouped_matmul(
                    x=[routed], weight=weights1, split_item=2, group_list_type=1,
                    group_type=0, group_list=groups,
                )[0]
                activation = torch_npu.npu_swiglu(gate)
                down = torch_npu.npu_grouped_matmul(
                    x=[activation], weight=weights2, split_item=2, group_list_type=1,
                    group_type=0, group_list=groups,
                )[0]
                return gate, activation, down, unpermute(down, masked_probs)

            stacked = staged([w1], [w2])
            listed = staged(split1, split2)
            # Verify that the diagnostic's stage split is exactly the runtime
            # helper, rather than merely another mathematical reference.
            helper_down, _ = apply_mlp(hidden_states=routed, w1=w1, w2=w2,
                                        group_list=groups, group_list_type=1, need_trans=False)
            assert torch.equal(stacked[2][:used_rows], helper_down[:used_rows]), 'REFERENCE_HELPER_DIFFERENCE'
            for _ in range(3):
                repeat = staged([w1], [w2])
                assert all(torch.equal(a, b) for a, b in zip(valid_stages(stacked), valid_stages(repeat))), 'OFF_REPEAT_DIFFERENCE'
                repeat = staged(split1, split2)
                assert all(torch.equal(a, b) for a, b in zip(valid_stages(listed), valid_stages(repeat))), 'LIST_REPEAT_DIFFERENCE'
            off_complete, list_complete = reduced(stacked[3]), reduced(listed[3])
            row = dict(
                name=name, rank=rank, real_global_tokens=tokens,
                valid_expert_rows=used_rows, allocated_routed_rows=routed.shape[0],
                input_sha256=input_sha, weight_sha256=weight_sha,
                reference='production ND stacked GMM, BF16 SwiGlu, actual masked BF16 unpermute, BF16 rank sum',
                list_vs_stack={stage: difference(a, b) for stage, a, b in zip(
                    ['gmm1', 'activation', 'gmm2', 'local_unpermute'], valid_stages(listed), valid_stages(stacked))},
                list_final_vs_off=difference(list_complete, off_complete),
                reference_helper_exact=True, repeat_each_representation=3,
            )
            result_file = outdir / f'{name}_rank{rank}.json'
            assert not result_file.exists()
            result_file.write_text(json.dumps(row, indent=2))
            if tokens >= 1:
                # Helper EP1 denotes one full sentinel block replicated on all
                # four ranks; the operator and HCCL group remain EP4.
                xx, ii, pp, active, original = append_dummy(
                    x, ids, probs, input_active, EXPERTS, 0, 1, dummy_cache={}
                )
                assert original == tokens and len(xx) == original + 32
                hashes = [None] * WORLD
                dist.all_gather_object(hashes, fingerprint([xx, ii, pp, active]))
                assert len(set(hashes)) == 1, 'FULL_INPUT_AND_SENTINELS_MISMATCH' 

                def fused(weights1, weights2):
                    return mega_moe(xx, ii.to(torch.int32), pp.to(torch.float32), weights1, weights2, symm,
                                    l1_weights_sf=None, l2_weights_sf=None, x_active_mask=active,
                                    weight1_type=None, weight2_type=None)

                actual, expert_counts = fused([w1], [w2])
                torch.npu.synchronize()
                active_counts = torch.bincount(ids[input_active.bool()].flatten().to(torch.int64), minlength=EXPERTS)
                expected_local_counts = active_counts[rank * local_e:(rank + 1) * local_e]
                assert torch.equal(expert_counts.flatten().to(torch.int64), expected_local_counts + 1), 'MEGAMOE_EXPERT_COUNTS'
                for _ in range(3):
                    again, again_counts = fused([w1], [w2])
                    assert torch.equal(actual, again) and torch.equal(expert_counts, again_counts), 'MEGAMOE_REPEAT_DIFFERENCE'
                row['mega_local_vs_off_local'] = difference(actual[:original], stacked[3])
                full_actual = reduced(actual[:original])
                row['mega_vs_off'] = difference(full_actual, off_complete)
                row['mega_vs_list_rank_sum'] = difference(full_actual, list_complete)
                # Recover each unweighted expert output with the actual
                # unpermute API. Only its owner contributes to each slot, so
                # this transfer does not introduce a mixed-expert sum.
                early_sum = torch.zeros_like(x, dtype=torch.float32)
                for k in range(TOPK):
                    one_slot = torch.zeros_like(probs)
                    one_slot[:, k] = mask[:, k].to(torch.bfloat16)
                    expert_slot = reduced(unpermute(listed[2], one_slot))
                    early_sum.add_(expert_slot.float() * probs[:, k].float().unsqueeze(-1))
                early_sum = early_sum.to(torch.bfloat16)
                row['early_topk_sum_vs_off'] = difference(early_sum, off_complete)
                row['mega_vs_early_topk_sum'] = difference(full_actual, early_sum)
                result_file.write_text(json.dumps(row, indent=2))
                # Discriminating storage-contract test: retaining OFF stacked
                # weights without duplicate expert copies is useful only if
                # the packed CANN output matches the retained ND per-expert views.
                view_actual, view_counts = fused(views1, views2)
                torch.npu.synchronize()
                row['views_vs_packed_mega'] = difference(view_actual, actual)
                assert row['views_vs_packed_mega']['bitwise_equal'] and torch.equal(view_counts, expert_counts), 'VIEW_WEIGHT_CONTRACT_DIFFERENCE'
                row['view_weight_shared_storage'] = all(v.untyped_storage().data_ptr() == w1.untyped_storage().data_ptr() for v in views1)
                assert row['view_weight_shared_storage']
                row['expert_count_check'] = 'real local count plus one sentinel per local expert'
                row['local_and_final_bitwise_acceptance'] = (row['mega_local_vs_off_local']['bitwise_equal'] and row['mega_vs_off']['bitwise_equal'])
            row['diagnostic_complete'] = True
            row['accuracy_acceptance'] = False
            result_file.write_text(json.dumps(row, indent=2))
            print('CASE_DIAGNOSTIC', json.dumps(row), flush=True)
            dist.barrier()
    loaded = sorted({line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines()
                     if 'libcust_opapi.so' in line})
    assert str(vendor / 'op_api/lib/libcust_opapi.so') in loaded
    symm.destroy()
    dist.barrier()
    dist.destroy_process_group()
    (outdir / f'complete_rank{rank}.json').write_text(json.dumps(dict(
        status='DIAGNOSTIC_COMPLETE_NOT_ACCURACY_ACCEPTANCE', rank=rank, cases=len(cases),
        reference_source_shas=REFERENCE_SHAS, loaded_opapi=loaded,
        performance_measured=False, full_model_accuracy_measured=False,
    ), indent=2))


if __name__ == '__main__':
    assert len(sys.argv) == 2
    if sys.argv[1] == '--validate-only':
        validate_runtime()
    else:
        main(sys.argv[1])
