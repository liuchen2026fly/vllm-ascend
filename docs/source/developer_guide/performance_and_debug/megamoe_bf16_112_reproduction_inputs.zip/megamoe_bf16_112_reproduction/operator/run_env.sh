#!/usr/bin/env bash
set -euo pipefail
set +u
source /usr/local/Ascend/ascend-toolkit/set_env.sh
set -u
export ASCEND_RT_VISIBLE_DEVICES=0,1,2,3
export HCCL_IF_IP=183.236.60.18
export GLOO_SOCKET_IFNAME=enp189s0f0
export TP_SOCKET_IFNAME=enp189s0f0
export HCCL_SOCKET_IFNAME=enp189s0f0
export HCCL_OP_EXPANSION_MODE=AIV HCCL_BUFFSIZE=1024 HCCL_DETERMINISTIC=true
export OMP_NUM_THREADS=100 TASK_QUEUE_ENABLE=1
export PYTORCH_NPU_ALLOC_CONF=expandable_segments:True
vend=/data1/megamoe_gain_20260905/bf16_opt_20260907/package_v30/packages/vendors/mmbf16v30_transformer
va=/data1/megamoe_gain_20260905/bf16_e2e_20260907/model_v15a_runtime/vllm-ascend-bf16
export ASCEND_CUSTOM_OPP_PATH="$vend:$va/vllm_ascend/_cann_ops_custom/vendors/custom_transformer"
export LD_LIBRARY_PATH="$vend/op_api/lib:${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$va:/data1/megamoe_gain_20260905/bf16_opt_20260907/torch_extension_v26:${PYTHONPATH:-}"
export TORCH_EXTENSIONS_DIR=/data1/megamoe_gain_20260905/bf16_opt_20260907/torch_extensions_v26
export MMGAIN_EXPECTED_VENDOR="$vend"
export MMGAIN_EXPECTED_ND_SHA=325ec7a0b8060e8070f8156c8a685003d3be4ffd1a3b7a8f54051fcf6154a42b
export MMGAIN_EXPECTED_EXTENSION_MANIFEST=/data1/megamoe_gain_20260905/bf16_opt_20260907/results/extension_v26_cpu_manifest.json
export MAX_JOBS=8 VLLM_USE_V2_MODEL_RUNNER=0 MEGAMOE=1
unset PROFILING_MODE VLLM_ASCEND_ENABLE_FLASHCOMM1
exec "$@"
