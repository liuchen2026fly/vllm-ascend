"""Verify immutable evidence, then reuse the existing timing/profile analyses."""
from pathlib import Path
import hashlib
import json
import math
import statistics
import subprocess
import sys
import zipfile

root=Path(__file__).resolve().parent
archive=root/'operator_weight_contract_evidence.zip'
proof=json.loads((root/(archive.name+'.download.json')).read_text())
assert hashlib.sha256(archive.read_bytes()).hexdigest()==proof['sha256']
evidence=root/'operator_weight_contract_evidence'
resume=sys.argv[1:]==['--resume-verified']
evidence.mkdir(exist_ok=resume)
with zipfile.ZipFile(archive) as z:
 for n in z.namelist():assert not n.startswith('/') and '..' not in Path(n).parts
 if resume:
  for n in z.namelist():assert (evidence/n).read_bytes()==z.read(n),n
 else:z.extractall(evidence)
manifest=json.loads((evidence/'manifest.json').read_text())
for name,sha in manifest['files'].items():assert hashlib.sha256((evidence/name).read_bytes()).hexdigest()==sha,name
for n in ['static.rc','run.rc','postflight.rc','controller.rc']:assert (evidence/n).read_text().strip()=='0',n
data={}
analysis={}
gaps={}
for variant in ['views','packed']:
 p=root/'operator_weight_contract_analysis'/variant
 raw=(evidence/('operator_'+variant+'_raw_results.json')).read_bytes()
 if resume:assert (p/'v31_operator_raw_results.json').read_bytes()==raw
 else:(p/'v31_operator_raw_results.json').write_bytes(raw)
 data[variant]=json.loads(raw)
 for name in ([] if resume else ['analyze_native.py','analyze_prepare.py']):
  result=subprocess.run([sys.executable,'-X','utf8',str(p/name)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (p/(name+'.log')).write_bytes(result.stdout)
  assert result.returncode==0,(variant,name,result.stdout[-3000:].decode(errors='replace'))
 analysis[variant]=json.loads((p/'v31_operator_remeasurement_summary.json').read_text())
 gaps[variant]=json.loads((p/'v31_operator_prepare_gap_summary.json').read_text())
 assert analysis[variant]['source_raw_sha256']==hashlib.sha256(raw).hexdigest()
 assert gaps[variant]['source_sha256']==hashlib.sha256(raw).hexdigest()
 for phase in ['timing','profile']:
  assert (evidence/variant/(phase+'.rc')).read_text().strip()=='0'
  cases=[json.loads(p.read_text()) for p in (evidence/variant/phase).glob('*_rank*.json') if not p.name.startswith('complete')]
  assert len(cases)==(48 if phase=='timing' else 16),(variant,phase,len(cases))
  assert all(x['reference_difference']['bitwise_equal'] and x['async_repeats_each_arm']==20 for x in cases)
key=lambda r:(r['scope'],r['tokens'],r['rank'])
left={key(r):r for r in data['views']['timing_records']}
right={key(r):r for r in data['packed']['timing_records']}
assert set(left)==set(right) and len(left)==48
assert all(left[k]['input_sha256']==right[k]['input_sha256'] and left[k]['weight_sha256']==right[k]['weight_sha256'] for k in left)
rows=[]
for r in data['packed']['comparisons']:
 old=next(v for v in data['views']['comparisons'] if v['scope']==r['scope'] and v['tokens']==r['tokens'])
 row=dict(scope=r['scope'],tokens=r['tokens'],off_ms=r['off_ms'],packed_ms=r['on_ms'],packed_vs_off_percent=r['latency_change_percent'],packed_pairs=r['pair_changes_percent'],views_off_ms=old['off_ms'],views_ms=old['on_ms'],views_vs_off_percent=old['latency_change_percent'],off_between_variants_percent=(r['off_ms']/old['off_ms']-1)*100)
 rows.append(row)
profile=[]
for variant in ['views','packed']:
 for t in [512,4096,6144,8192]:
  gr=[r for r in gaps[variant]['rows'] if r['tokens']==t]
  nr={r['device']:r for r in analysis[variant]['native'] if r['tokens']==t}
  off=[max(r['samples_us']['off_prepare_to_unpermute_span_us'][i] for r in gr) for i in range(20)]
  on=[max(r['samples_us']['on_span_us'][i] for r in gr) for i in range(20)]
  selected=[max(gr,key=lambda r:r['samples_us']['on_span_us'][i]) for i in range(20)]
  components=dict(prepare_us=statistics.mean(r['samples_us']['on_prepare_us'][i] for i,r in enumerate(selected)),gap_us=statistics.mean(r['samples_us']['on_prepare_to_mega_gap_us'][i] for i,r in enumerate(selected)),mega_us=statistics.mean(nr[r['device']]['samples_us']['on_mega_us'][i] for i,r in enumerate(selected)))
  timestamp_ulp=max(math.ulp(task['start_us']) for device in data[variant]['native'] for task in device['tasks'])
  residuals=[r['samples_us']['on_prepare_us'][i]+r['samples_us']['on_prepare_to_mega_gap_us'][i]+nr[r['device']]['samples_us']['on_mega_us'][i]-r['samples_us']['on_span_us'][i] for i,r in enumerate(selected)]
  assert max(map(abs,residuals))<=2*timestamp_ulp+1e-9
  bm=lambda xs:statistics.mean(statistics.median(xs[i:i+10]) for i in [0,10])
  profile.append(dict(variant=variant,tokens=t,off_span_us=bm(off),on_span_us=bm(on),latency_change_percent=(bm(on)/bm(off)-1)*100,critical_rank_component_means=components,critical_span_mean_us=statistics.mean(on),off_span_mean_us=statistics.mean(off),timestamp_ulp_us=timestamp_ulp,max_component_residual_us=max(map(abs,residuals))))
result=dict(status='HEADROOM_WEIGHT_CONTRACT_ANALYZED',host='112.29.145.3',manifest=manifest,source_unchanged=True,evidence=proof,precision=dict(timed_cases=96,profiled_cases=32,bitwise=True,queued_repeats_per_arm=20,all_weight_input_hashes_match=True),unprofiled=rows,native_aggregate={v:analysis[v]['native_aggregate'] for v in ['views','packed']},profile_with_prepare=profile,interpretation='Packed is the existing production contract, not a new production optimization. Each variant has its own OFF-ON-ON-OFF baseline. Profiles are separate diagnostic runs. Components are means from the slowest ON rank selected per sample; they sum to mean span, not median span. Synthetic routing, no actual shared-expert MLP/overlap or model scheduling.')
(root/'HEADROOM_SUMMARY.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
for row in rows:print('UNPROFILED',json.dumps(row))
for row in profile:print('PROFILE',json.dumps(row))
print('ALL_CONTRACT_HASH_PRECISION_AND_CLEANUP_CHECKS_PASS')
