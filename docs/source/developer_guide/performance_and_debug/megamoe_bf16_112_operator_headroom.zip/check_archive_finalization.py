"""Reject computing a ZIP path's digest while its write context is still open."""
import ast
from pathlib import Path
import re
import sys

def check(source):
 tree=ast.parse(source)
 for node in ast.walk(tree):
  if not isinstance(node,ast.With):continue
  for item in node.items:
   call=item.context_expr
   if not isinstance(call,ast.Call) or not isinstance(call.func,ast.Attribute) or call.func.attr!='ZipFile':continue
   mode=call.args[1] if len(call.args)>1 else next((x.value for x in call.keywords if x.arg=='mode'),ast.Constant('r'))
   if not isinstance(mode,ast.Constant) or mode.value not in ['w','x','a']:continue
   target=ast.dump(call.args[0])
   for child in ast.walk(ast.Module(body=node.body,type_ignores=[])):
    if isinstance(child,ast.Call) and isinstance(child.func,ast.Attribute) and child.func.attr=='read_bytes' and ast.dump(child.func.value)==target:
     raise ValueError('ZIP_PATH_READ_BEFORE_WRITER_CLOSE')

if __name__=='__main__':
 check("with zipfile.ZipFile(zpath, 'x') as z:\n z.write(p)\nprint(hashlib.sha256(zpath.read_bytes()).hexdigest())\n")
 try:check("with zipfile.ZipFile(zpath, 'x') as z:\n print(hashlib.sha256(zpath.read_bytes()).hexdigest())\n")
 except ValueError:pass
 else:raise AssertionError('REGRESSION_GUARD_FAILED')
 for arg in sys.argv[1:]:
  p=Path(arg);s=p.read_text(encoding='utf-8')
  parts=re.findall(r"<<'PY'\n(.*?)\nPY",s,re.S) if p.suffix=='.sh' else [s]
  assert parts
  for part in parts:check(part)
 print('ZIP_FINALIZATION_GUARD_PASS')
