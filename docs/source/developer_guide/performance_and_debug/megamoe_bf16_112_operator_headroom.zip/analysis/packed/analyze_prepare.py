from pathlib import Path
import hashlib,json,statistics

root=Path(__file__).resolve().parent
source=root/'v31_operator_raw_results.json'
data=json.loads(source.read_bytes())
selected=list(range(31,41))+list(range(51,61))
rows=[]
for device in data['native']:
    shapes={s['id']:s for s in device['shapes']}
    tasks=device['tasks']
    def select(name,tokens,index=0):
        ids={s['id'] for s in shapes.values() if s['op']==name and s['input_shapes'].strip('"').split(';')[index].split(',')[0]==str(tokens)}
        assert len(ids)==1,(name,tokens,ids)
        result=[t for t in tasks if t['shape_id'] in ids]
        assert len(result)==61,(name,tokens,len(result))
        return result
    for tokens in data['manifest']['input_tokens']:
        prep=select('_prepare_local_partial_kernel',tokens)
        mega=select('MegaMoe',tokens+32,1)
        mask=select('GreaterEqual',tokens)
        unp=select('MoeTokenUnpermute',tokens*8)
        metrics={k:[] for k in ['on_prepare_us','on_prepare_to_mega_gap_us','on_span_us','on_busy_us','off_prepare_to_unpermute_span_us','off_busy_us','off_idle_us']}
        for i in selected:
            a,b=prep[i],mega[i]
            assert a['stream_id']==b['stream_id']
            end=b['start_us']+b['duration_us']
            inside=[t for t in tasks if t['stream_id']==a['stream_id'] and a['start_us']<=t['start_us']<end]
            assert len(inside)==2,('EXPECTED_PREP_PLUS_MEGA_ONLY',tokens,device['device'],i,inside)
            gap=b['start_us']-(a['start_us']+a['duration_us'])
            assert gap>=-0.3
            metrics['on_prepare_us'].append(a['duration_us'])
            metrics['on_prepare_to_mega_gap_us'].append(max(0,gap))
            metrics['on_span_us'].append(end-a['start_us'])
            metrics['on_busy_us'].append(a['duration_us']+b['duration_us'])
            a,b=mask[i],unp[i]
            assert a['stream_id']==b['stream_id']
            end=b['start_us']+b['duration_us']
            inside=[t for t in tasks if t['stream_id']==a['stream_id'] and a['start_us']<=t['start_us']<end]
            busy=sum(t['duration_us'] for t in inside)
            span=end-a['start_us']
            assert span+1>=busy
            metrics['off_prepare_to_unpermute_span_us'].append(span)
            metrics['off_busy_us'].append(busy)
            metrics['off_idle_us'].append(max(0,span-busy))
        row=dict(device=device['device'],tokens=tokens,median_us={k:statistics.median(v) for k,v in metrics.items()},samples_us=metrics)
        rows.append(row)
        print('PREPARATION_GAP',json.dumps({k:v for k,v in row.items() if k!='samples_us'}))
result=dict(source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),rows=rows,
            scope='Same-stream native task intervals. Gap means no captured task in this main stream; it does not uniquely identify Python/C++ dispatch or other-stream work. No profiled/unprofiled subtraction.')
target=root/'v31_operator_prepare_gap_summary.json'
assert not target.exists()
target.write_bytes((json.dumps(result,indent=2)+'\n').encode())
