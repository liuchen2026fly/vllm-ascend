"""Copy only hash-verified diagnostic inputs into a fresh Linux task directory."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

source=Path(sys.argv[1]).resolve()
target=Path(sys.argv[2]).resolve()
base=Path('/data1/megamoe_gain_20260905/bf16_e2e_20260907')
assert target.parent==base and target.name.startswith('headroom_contract_replay_')
assert not target.exists()
m=json.loads((source/'manifest.json').read_text())
old=m['remote']
blobs={name:(source/name).read_bytes() for name in m['files']}
for name,b in blobs.items():
 assert '/' not in name and hashlib.sha256(b).hexdigest()==m['files'][name]
 assert b'\r' not in b and not b.startswith(b'\xef\xbb\xbf')
 if name.endswith('.sh'):
  subprocess.run(['bash','-n',str(source/name)],check=True)
for name in ['run_env.sh','run_contract_probe.sh']:
 text=blobs[name].decode()
 assert old in text
 blobs[name]=text.replace(old,str(target)).encode()
m['replay_parent_manifest_sha256']=hashlib.sha256((source/'manifest.json').read_bytes()).hexdigest()
m['remote']=str(target)
m['files']={n:hashlib.sha256(b).hexdigest() for n,b in blobs.items()}
target.mkdir()
for n,b in blobs.items():
 (target/n).write_bytes(b)
 if n.endswith('.sh'):subprocess.run(['bash','-n',str(target/n)],check=True)
(target/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print('FRESH_REPLAY_INPUTS_READY',target)
