# 四卡 BF16 单算子调用方式复测

`evidence/` 保存原始输入、两种权重方式的普通计时/精度记录、原生 msprof op_summary/API CSV 和退出状态；`analysis/` 保存既有分析程序与重算结果。`HEADROOM_SUMMARY.json` 是汇总。整个包没有替换生产源码或内核。

前置条件：按同目录 `megamoe_bf16_112_reproduction.md` 恢复已验收镜像、V31/V30 运行时与扩展。容器 mm_bf16_serve_20260907、四卡 0–3、HCCL bond1/192.168.0.2；测试不加载整模型。其它主机须先核实网络和设备配置，不能盲用此 IP。无 CPU 绑定，与旧单算子 harness 相同；不等同整网绑核配置。

在 112 主机将本 ZIP 解压到一个新目录，进入解压目录。以下使用全新任务目录，已有目录会拒绝覆盖：

```bash
set -euo pipefail
task=/data1/megamoe_gain_20260905/bf16_e2e_20260907/headroom_contract_replay_001
python3 -I prepare_contract_replay.py evidence "$task"
docker exec mm_bf16_serve_20260907 bash "$task/run_env.sh" python3 "$task/bench_packed.py" --validate-only > "$task/static.log" 2>&1
printf '0
' > "$task/static.rc"
docker exec mm_bf16_serve_20260907 python3 "$task/preflight.py"
bash "$task/run_contract_probe.sh"
test "$(cat "$task/controller.rc")" = 0
test "$(cat "$task/postflight.rc")" = 0
```

程序先测试 64 个二维 view 的历史对照，再测试生产单个三维权重张量。每种方式独立 OFF/ON/ON/OFF；每 block 预热 10、采样 30。512/4096/6144/8192 token，三个计时范围。每用例先验证 BF16 逐位相等与每侧 20 次连续调用；另一次 msprof 运行每 block 采样 10。新目录准备器已在 112 上验证 CPU 源码/二进制门禁，不启动服务。

离线复算已经保存的 profiling，在另一个空目录复制某种方式的三个文件，然后运行：

```bash
mkdir -p /tmp/megamoe_contract_recompute_001
cp analysis/packed/v31_operator_raw_results.json analysis/packed/analyze_native.py analysis/packed/analyze_prepare.py /tmp/megamoe_contract_recompute_001/
python3 /tmp/megamoe_contract_recompute_001/analyze_native.py
python3 /tmp/megamoe_contract_recompute_001/analyze_prepare.py
```

输出文件不覆盖既有结果。两种方式的输入与权重 SHA 已逐例核对一致。这里的 precision 仅覆盖合成用例；共享专家只加固定 partial，未包含其 MLP、多流重叠、真实路由、attention 或整网调度。不可把本报告的百分比当成 TTFT 或端到端吞吐收益。
