#!/usr/bin/env bash
set -euo pipefail
task=/data1/megamoe_gain_20260905/bf16_e2e_20260907/headroom_weight_contract_112_20260913
test "$(cat "$task/static.rc")" = 0
exec 9>/var/lock/megamoe_q36.lock
flock -n 9
docker exec mm_bf16_serve_20260907 python3 "$task/preflight.py"
test ! -e "$task/controller.log"
exec > "$task/controller.log" 2>&1
printf '%s
' "$$" > "$task/launcher.pid"
cat /proc/$$/stat > "$task/launcher.initial_stat"
finish() {
 rc=$?
 trap - EXIT
 set +e
 printf '%s
' "$rc" > "$task/run.rc"
 docker exec mm_bf16_serve_20260907 python3 "$task/preflight.py" > "$task/postflight.log" 2>&1
 post=$?
 printf '%s
' "$post" > "$task/postflight.rc"
 if test "$rc" = 0 && test "$post" != 0; then rc=$post; fi
 printf '%s
' "$rc" > "$task/controller.rc"
 exit "$rc"
}
trap finish EXIT
for variant in views packed; do
 out=$task/$variant
 mkdir -p "$out/timing" "$out/profile"
 docker exec mm_bf16_serve_20260907 bash "$task/run_env.sh" timeout --signal=TERM --kill-after=25s 720s torchrun --nproc_per_node=4 --master_addr=127.0.0.1 --master_port=29541 "$task/bench_$variant.py" "$out/timing" timing > "$out/timing.log" 2>&1
 printf '0
' > "$out/timing.rc"
 docker exec mm_bf16_serve_20260907 python3 "$task/preflight.py"
 docker exec mm_bf16_serve_20260907 bash "$task/run_env.sh" timeout --signal=TERM --kill-after=25s 720s msprof --output="$out/msprof" --ascendcl=on --runtime-api=on --task-time=on --ai-core=off torchrun --nproc_per_node=4 --master_addr=127.0.0.1 --master_port=29541 "$task/bench_$variant.py" "$out/profile" profile > "$out/profile.log" 2>&1
 printf '0
' > "$out/profile.rc"
 docker exec mm_bf16_serve_20260907 python3 "$task/preflight.py"
 printf '%s
' "VARIANT_COMPLETE $variant"
done
