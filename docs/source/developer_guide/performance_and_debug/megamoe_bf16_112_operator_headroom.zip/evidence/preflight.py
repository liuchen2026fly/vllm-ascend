from pathlib import Path
import json,socket,subprocess
info=subprocess.check_output(['npu-smi','info'],text=True)
for n in range(4):
 assert 'No running processes found in NPU %d'%n in info, ('DEVICE_BUSY',n)
for port in [8001,29541]:
 s=socket.socket();s.bind(('127.0.0.1',port));s.close()
workers=[]
for p in Path('/proc').glob('[0-9]*/stat'):
 try:
  stat=p.read_text();state=stat.rsplit(')',1)[1].split()[0]
  name=(p.parent/'comm').read_text().strip()
  if state!='Z' and name.startswith(('VLLM::EngineCore','VLLM::Worker')):workers.append((p.parent.name,name))
 except (FileNotFoundError,ProcessLookupError):pass
assert not workers,('ACTIVE_SERVING_WORKERS',workers)
print('SELECTED_DEVICES_PORTS_WORKERS_CLEAR',flush=True)
